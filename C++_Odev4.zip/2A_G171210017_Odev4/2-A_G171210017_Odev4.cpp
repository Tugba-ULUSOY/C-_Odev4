/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			         B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				    B�LG�SAYAR M�HEND�SL��� B�L�M�
**				          PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI�...:4
**				��RENC� ADI...............:Tu�ba ULUSOY
**				��RENC� NUMARASI.:G171210017
**				DERS GRUBU����:2.��retim - A Grubu
****************************************************************************/
#include<iostream>
#include<time.h>
#include<math.h>
#include<cstdlib>
using namespace std;

int* *olustur(int sayilar[10][10]); 
void matrisYaz(int* *sayilar);
int* *sirala(int* *sayilar[10][10]);
int main()
{
	int* *sayi = 0;
	int sayilar[10][10];// int sayilarla 10x10 luk bir kare matris �a��r�l�yor
	sayi = olustur(sayilar);
	matrisYaz(sayi);
	cout << endl;
	sirala(sayi);
	matrisYaz(sayi);
	system("PAUSE");
	return 0;
}
int* *olustur(int sayilar[10][10])
{
	srand(time(NULL)); // rand fonksiyonunda zamanla de�i�iklik yaps�n diye kullan�l�r
	int* *sayilarr = 0;
	sayilarr = new int*[10];
	for (int i = 0; i < 10; i++)
	{
		sayilarr[i] = new int[10];
		for (int j = 0; j < 10; j++)
		{
			sayilar[i][j] = rand() % 100 + 1;
			sayilarr[i][j] = sayilar[i][j];
		}
	}
	return sayilarr;
}

void matrisYaz(int* *sayilar)
{
	sayilar[10][10];
	for (int i = 0; i < 10 ; i++)
	{
		for(int j=0 ; j < 10; j++)
		{
			cout << " " << sayilar[i][j];
		}
		cout << endl;
	}
}

int* *sirala(int* *sayilar[10][10])
{
	sayilar[10][10];
	for(int a=0; a<10; a++)
		for (int b = 0; b<10; b++)
			for (int d = 0; d<10; d++)
				for (int e = 0; e < 10; e++)
				{
					if (sayilar[a][b] > sayilar[d][e])
					{
						sayilar[a][b] = sayilar[a][b] + sayilar[d][e];
						sayilar[d][e] = sayilar[a][b] - sayilar[d][e];
						sayilar[a][b] = sayilar[a][b] - sayilar[d][e];
					}
				}
		
}










 















